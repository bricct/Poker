cd ..
cd ..
javadoc -author -version -d ../docs -sourcepath "src" ./src/game/*.java
javadoc -author -version -d ../docs -sourcepath "src" ./src/netwrk/*.java
javadoc -author -version -d ../docs -sourcepath "src" ./src/sound/*.java
javadoc -author -version -d ../docs -sourcepath "src" ./src/ui/frames/*.java
javadoc -author -version -d ../docs -sourcepath "src" ./src/ui/panels/*.java