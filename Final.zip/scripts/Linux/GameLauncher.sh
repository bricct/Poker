cd ..
cd ..
java -cp "bin" ui.Run