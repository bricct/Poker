package game;

public class PlayerTuple
{
    public Player player;
    int currMoney;
    public PlayerTuple(Player iplayer, int icurrMoney)
    {
        player = iplayer;
        currMoney = icurrMoney;
    }
}
